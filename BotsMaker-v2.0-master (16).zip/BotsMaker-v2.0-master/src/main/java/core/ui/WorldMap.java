package core.ui;

import com.badlogic.gdx.scenes.scene2d.Stage;

public class WorldMap {
	
	public Stage stage;
	
	public WorldMap() {
		stage = new Stage();
	}
	
	public void draw() {
		stage.act();
		stage.draw();
	}
}
