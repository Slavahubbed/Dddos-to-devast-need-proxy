package core.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Action;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.SelectBox;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.utils.Array;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.jayway.jsonpath.JsonPath;
import com.kotcrab.vis.ui.VisUI;

import core.Core;
import core.net.server.GetServerListClass;
import core.net.server.Server;
import net.minidev.json.JSONArray;

public class Menu {
	
	//Батч
	private SpriteBatch batch;
	//Камера
	private OrthographicCamera camera;
	//Виевпорт
	private FitViewport viewport;
	//Стэйдж элементов меню
	private Stage stage;
	//Скин для элементов
	private Skin skin;
	//Таблица для элементов
	private Table all;
	//Класс для получения списка серверов
	private GetServerListClass serverGetter;
	//Различные элементы
	private TextButton refreshButton;
	private SelectBox<String> serverList;
	private TextButton stateButton;
	
	public void init() {
		camera = new OrthographicCamera();
		viewport = new FitViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), camera);
		batch = new SpriteBatch();
		stage = new Stage(viewport, batch);
		skin = VisUI.getSkin();
		all = new Table().left().top();
		
		all.setSize(200, viewport.getWorldHeight());
		
		serverGetter = new GetServerListClass();
		refreshButton = new TextButton("R", skin);
		initRefreshButtonListener();
		serverList = new SelectBox<String>(skin);
		initSelectBoxListener();
		stateButton = new TextButton("Start", skin);
		initStartButton();
		
		all.add(serverList).width(170).height(25).pad(3).padRight(25);
		all.add(refreshButton).width(25).height(25).padLeft(-22).row();
		all.add(stateButton).width(200).height(25).padRight(-4).row();;
		all.add(new TextVariableField());
		
		stage.setDebugAll(false);
		stage.addActor(all);
	}
	
	public void draw(float delta) {
		stage.act(delta);
		stage.draw();
	}
	
	public void resize(int width, int height) {
		viewport.setScreenSize(width, height);
	}
	
	public Stage getStage() {
		return stage;
	}
	
	private void initRefreshButtonListener() {
		InputListener refreshButtonListener = new InputListener() {		
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				String s = serverGetter.serverList();
				JSONArray s1 = JsonPath.read(s, "lobbies");
				Array<String> names = new Array<String>();
				
				Array<String> fr = new Array<String>();
				Array<String> sf = new Array<String>();
				Array<String> tk = new Array<String>();
				Array<String> atl = new Array<String>();
				Array<String> sd = new Array<String>();
				for(int i = 0; i < s1.size(); i++) {
					String region = JsonPath.read(s1.get(i), "region_id");
					String mode = JsonPath.read(s1.get(i), "game_mode_id");
					String ip = JsonPath.read(s1.get(i), "lobby_id");
					int count = JsonPath.read(s1.get(i), "total_player_count");
					
					switch (region) {
						case "lnd-fra" : names.add("Frankfurt-" + (fr.size + 1) + ", Mode: " + mode + " | " + count); fr.add(""); Core.servers.add(new Server(i, ip, region, "FR-" + (fr.size))); break;
						case "lnd-sfo": names.add("San-Franc-" + (sf.size + 1) + ", Mode: " + mode + " | " + count); sf.add(""); Core.servers.add(new Server(i, ip, region, "SF-" + (sf.size))); break;
						case "lnd-tok": names.add("Tokyo-" + (tk.size + 1) + ", Mode: " + mode + " | " + count); tk.add(""); Core.servers.add(new Server(i, ip, region, "TK-" + (tk.size))); break;
						case "lnd-atl": names.add("Atlanta-" + (atl.size + 1) + ", Mode: " + mode + " | " + count); atl.add(""); Core.servers.add(new Server(i, ip, region, "ATL-" + (atl.size))); break;
						case "lnd-syd": names.add("Sydney-" + (sd.size + 1) + ", Mode: " + mode + " | " + count); sd.add(""); Core.servers.add(new Server(i, ip, region, "SD-" + (sd.size))); break;
						default: throw new IllegalArgumentException("Unexpected value: " + "|" + region + "|");
					}
				};
				serverList.setItems(names);
				return false;
			}
			
		};
		refreshButton.addListener(refreshButtonListener);
	}
	public void initSelectBoxListener() {
		Action action = new Action() {
			
			@Override
			public boolean act(float delta) {
				if(Core.selectedServer != serverList.getSelectedIndex()) {
					Core.selectedServer = serverList.getSelectedIndex();
				}
				return false;
			}
		};
		serverList.addAction(action);
	}
	
	public void initStartButton() {
		InputListener listener = new InputListener() {
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				Core.state = !Core.state;
				if(Core.state) stateButton.setText("Stop"); else {
					stateButton.setText("Start");
					for(int i = 0; i < Core.bots.size; i++) {
						Core.bots.get(i).disconnect();
					}
					Core.bots.clear();
					Core.selectedBots.clear();
				}
				return false;
			}
		};
		stateButton.addListener(listener);
	}
}
