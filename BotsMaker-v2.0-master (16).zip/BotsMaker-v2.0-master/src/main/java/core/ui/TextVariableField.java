package core.ui;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.kotcrab.vis.ui.VisUI;

public class TextVariableField extends Table {
	
	private Table textContainer;
	private int size = 0;
	
	public TextButton addButton;
	
	public TextVariableField() {
		textContainer = new Table();
		textContainer.setSize(200, 300);
		textContainer.top().left();
		textContainer.setDebug(true);
		textContainer.row();
		addButton = new TextButton("+", VisUI.getSkin());
		addButton.row();
		initAddButton();
		add(textContainer, addButton);
	}
	
	protected void initAddButton() {
		addButton.addListener(new InputListener() {
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				size++;
				TextButton test = new TextButton("ABCD", VisUI.getSkin());
				if(size == 4) {
					textContainer.add(test).row();
					size = 0;
				} else textContainer.add(test);
				return false;
			}
		});
	}
	
	public void addField(String text) {
		
	}
}
