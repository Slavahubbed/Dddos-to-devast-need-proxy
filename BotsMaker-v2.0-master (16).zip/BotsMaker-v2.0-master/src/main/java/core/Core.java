package core;

import java.util.HashMap;

import com.badlogic.gdx.utils.Array;

import core.entities.Bot;
import core.entities.Player;
import core.net.server.Server;
import core.world.World;

public class Core {
	//Список серверов
	public static Array<Server> servers = new Array<Server>();
	//Состояние бот спамера
	public static boolean state = false;
	//Выбранный сервер
	public static int selectedServer = 0;
	//Айди прокси
	public static int proxyID = 0;
	//Айди прокси с паролем
	public static int proxyWithPasswordID = 0;
	//Максимальный размер
	public static int maxSize = 2;
	//Зум камеры
	public static float cameraZoom = 1f;
	//Массив ботов
	public static Array<Bot> bots;
	//Массив ботов под управлением
	public static Array<Bot> selectedBots;
	//Массив игроков, нацеленных на атаку
	public static Array<Player> selectedPlayers;
	//Мир
	public static World world;
	//
	public static boolean canAtack = false;
	//Массив игроков
	public static HashMap<Integer, Player> players;
}
