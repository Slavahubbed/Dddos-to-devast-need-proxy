package core.world;

import core.world.content.Blocks;

public class World {
	
	public static Map map;
	
	public static WorldRenderer worldRenderer;
	
	public void init() {
		Blocks.load();
		worldRenderer = new WorldRenderer(this);
		map = new Map();
		map.init();
	}
	
	public void update(float delta) {
		worldRenderer.update();
		worldRenderer.draw();
	}
	
	public void resize(float width, float height) {
		worldRenderer.resize(width, height);
	}
}
