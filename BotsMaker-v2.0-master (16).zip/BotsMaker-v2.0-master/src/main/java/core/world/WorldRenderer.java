package core.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import core.Core;
import core.Vars;

public class WorldRenderer {
	
	public SpriteBatch batch;
	public OrthographicCamera camera;
	public Viewport viewport;
	
	public static Stage stage;
	
	public WorldRenderer(World world) {
		this.batch = new SpriteBatch();
		this.camera = new OrthographicCamera();
		this.viewport = new FitViewport(Gdx.graphics.getWidth(), Gdx.graphics.getHeight(), camera);

		stage = new Stage(viewport, batch);
		stage.setDebugAll(false);
		camera.setToOrtho(true);
		camera.zoom = Core.cameraZoom;
	}
	
	
	public void draw() {
		camera.update();
		batch.begin();
		batch.setProjectionMatrix(camera.combined);
		World.map.draw(batch);
		for(int i = 0; i < Core.bots.size; i++) {
			Core.bots.get(i).getClient().listener.draw(batch);
		}
		batch.end();
		stage.act();
		stage.draw();
	}
	
	public void update() {
		Vector2 vel = new Vector2();
		
		if(Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.UP)) {
			vel.y = -1;
		} else if(Gdx.input.isKeyPressed(Input.Keys.S) || Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
			vel.y = 1;
		}
		if(Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
			vel.x = -1;
		} else if(Gdx.input.isKeyPressed(Input.Keys.D) || Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
			vel.x = 1;
		}
		camera.zoom = Core.cameraZoom;
		camera.translate(vel.x * Vars.cameraSpeed, vel.y * Vars.cameraSpeed);
	}
	
	public void resize(float width, float height) {
		camera.viewportWidth = width;
		camera.viewportHeight = height;
	}
}
