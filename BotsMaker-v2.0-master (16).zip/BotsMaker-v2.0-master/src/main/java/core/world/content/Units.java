package core.world.content;

import core.world.tiles.Unit;

public class Units {
	
	public static Unit player, ghoul, fastGhoul, radGhoul, shahid, titan;
	static Unit[] units;
	
	public static void load() {
		player = new Unit("player.png", 0) {{
			skin = -1;
		}};
		
		ghoul = new Unit("ghoul.png", 0) {{
			skin = 0;
		}};
		fastGhoul = new Unit("fast-ghoul.png", 0) {{
			skin = 1;
		}};
		radGhoul = new Unit("rad-ghoul.png", 0) {{
			skin = 3;
		}};
		shahid = new Unit("shahid.png", 0) {{
			skin = 2;
		}};
		titan = new Unit("titan.png", 0) {{
			skin = 4;
		}};
		
		units = new Unit[] {player, ghoul, fastGhoul, radGhoul, shahid, titan};
	}
	
	public static Unit getUnit(int skin) {
		System.out.println("SKIN: " + skin);
		for(Unit u : units) {
			if(u.skin == skin) {
				return u;
			}
		}
		return player;
	}
}
