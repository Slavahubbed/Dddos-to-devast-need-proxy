package core.world.content;

import com.badlogic.gdx.utils.Array;

import core.world.tiles.Block;

public class Blocks {
	
	public static Block none, wall, tree, stone, orange, steel, uranium, sulfur, leaftree, tomato, boar, deer, mushroom1, mushroom2, mushroom3, floar;
	
	private static Array<Block> blocks;
	
	public static void load() {
		none = new Block("air.png", -1) {{
		}};
		wall = new Block("wall.png", 3) {{
			skin = -2;
		}};
		tree = new Block("tree.png", 9) {{
			skin = 0;
		}};
		stone = new Block("stone.png", 9) {{
			skin = 1;
		}};
		steel = new Block("steel.png", 9) {{
			skin = 2;
		}};
		uranium = new Block("uranium.png", 9) {{
			skin = 3;
		}};
		sulfur = new Block("sulfur.png", 9) {{
			skin = 4;
		}};
		leaftree = new Block("tree.png", 9) {{
			skin = 5;
		}};
		orange = new Block("orange.png", 9) {{
			skin = 6;
		}};
		tomato = new Block("tomato.png", 9) {{
			skin = 7;
		}};
		boar = new Block("boar.png", 9) {{
			skin = 8;
		}};
		deer = new Block("deer.png", 9) {{
			skin = 9;
		}};
		mushroom1 = new Block("mushroom1.png", 9) {{
			skin = 10;
		}};
		mushroom2 = new Block("mushroom1.png", 9) {{
			skin = 11;
		}};
		mushroom3 = new Block("mushroom1.png", 9) {{
			skin = 12;
		}};
		floar = new Block("antidote-tree.png", 9) {{
			skin = 13;
		}};
		
		blocks = new Array<Block>();
		Block[] blocks1 = new Block[] {wall, tree, stone, orange, steel, uranium, sulfur, leaftree, tomato, boar, deer, mushroom1, mushroom2, mushroom3, floar};
		blocks.addAll(blocks1);
	}
	
	public static Block get(int type, int skin) {
		for(Block b: blocks) {
			if((type == 8 || type == 9 || type == 10 || type == 11) && b.skin == skin) {
				return b;
			}
		}
		return none;
	}
}
