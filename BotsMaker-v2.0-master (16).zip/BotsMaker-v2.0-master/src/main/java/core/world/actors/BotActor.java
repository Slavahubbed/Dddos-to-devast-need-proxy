package core.world.actors;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;

import core.Core;
import core.Vars;
import core.entities.Bot;
import core.world.content.Units;
import core.world.tiles.Unit;

public class BotActor extends Actor {
	
	private Bot bot;
	private Unit unit;
	
	public BotActor(Bot bot) {
		this.bot = bot;
		setBounds(0, 0, 100, 100);
		init();
	}
	
	public void init() {
		addListener(new InputListener() {
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				bot.selected = !bot.selected;
				if(bot.selected) {
					Core.selectedBots.add(bot);
				} else Core.selectedBots.removeValue(bot, false);
				return false;
			}
		});
		unit = Units.getUnit(bot.skin - 1);
	}
	
	public void updatePosition(float x, float y) {
		setPosition(x, y);
	}

	@Override
	public void draw(Batch batch, float parentAlpha) {
		batch.draw(unit.texture, getX(), getY(), Vars.tileSize, Vars.tileSize);
		if(bot.selected) bot.onSelected(batch);
	}	
	
}
