package core.world.actors;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;

import core.Core;
import core.Vars;
import core.entities.Bot;

public class TileActor extends Actor {
	
	public Vector2 position;
	
	public TileActor(Vector2 position) {
		this.position = position;
		init();
	}
	
	public void init() {
		
		setBounds(position.x, position.y, Vars.tileSize, Vars.tileSize);
		
		addListener(new InputListener() {
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				if(Core.selectedBots.size > 0) {
					for(Bot bot: Core.selectedBots) {
						System.out.println(position.toString());
						bot.targetPoint = position;
						bot.targetPlayer = null;
					}
				}
				return false;
			}
		});
	}
}
