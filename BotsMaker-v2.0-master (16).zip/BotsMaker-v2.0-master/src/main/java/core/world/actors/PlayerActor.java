package core.world.actors;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.InputListener;

import core.Core;
import core.Textures;
import core.Vars;
import core.entities.Bot;
import core.entities.Player;

public class PlayerActor extends Actor {
	
	private Player player;
	
	public PlayerActor(Player player) {
		this.player = player;
	}
	
	public void init() {
		addListener(new InputListener() {
			@Override
			public boolean touchDown(InputEvent event, float x, float y, int pointer, int button) {
				for(Bot bot : Core.selectedBots) {
					bot.targetPlayer = player;
					System.out.println(player.getPosition().toString());
				}
				return false;
			}
		});
	}
	
	@Override
	public void draw(Batch batch, float parentAlpha) {
		setBounds(player.getPosition().x, player.getPosition().y, Vars.tileSize, Vars.tileSize);
		batch.draw(Textures.player, player.getPosition().x, player.getPosition().y, Vars.tileSize, Vars.tileSize);
	}
}
