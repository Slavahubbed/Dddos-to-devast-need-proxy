package core.world;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

import core.world.actors.TileActor;

public class Map {
	
	private Texture map;
	
	public void init() {
		map = new Texture(Gdx.files.internal("sprites/bigMap.png"));
		for(int i = 50; i < 15000; i += 100) {
			for(int j = 50; j < 15000; j += 100) {
				WorldRenderer.stage.addActor(new TileActor(new Vector2(j, i)));
			}
		}
	}
	
	public void draw(SpriteBatch batch) {
		batch.draw(map, 50, 50, 15000, 15000);
	}
	
}
