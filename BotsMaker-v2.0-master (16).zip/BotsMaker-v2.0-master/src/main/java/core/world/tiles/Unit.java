package core.world.tiles;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;

import core.entities.Entity;

public class Unit extends Entity {

	public int skin;
	public Texture texture;
	
	public Unit(String texture, int type) {
		super(texture, type);
		this.texture = new Texture(Gdx.files.internal("sprites/" + texture));
	}
	
}
