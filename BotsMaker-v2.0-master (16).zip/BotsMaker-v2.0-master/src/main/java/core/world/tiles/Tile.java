package core.world.tiles;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import core.Vars;
import core.entities.Entity;
import core.world.content.Blocks;

public class Tile extends Entity {
	
	public Block block;
	
	
	public Tile(int type) {
		super(type);
		block = Blocks.none;
	}
	
	public void draw(SpriteBatch batch) {
		batch.draw(block.texture, position.x, position.y, Vars.tileSize, Vars.tileSize);
	}
}
