package core.world.tiles;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import core.entities.Entity;

public class Block extends Entity {
	
	public Texture texture;
	public int skin;
	
	public Block(String texture, int type) {
		super(texture, type);
		this.texture = new Texture(Gdx.files.internal("sprites/" + texture));
	}
	
	public void draw(SpriteBatch batch) {
		batch.draw(texture, position.x, position.y);
	}
}
