package core.app;

import java.util.HashMap;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.utils.Array;

import core.Core;
import core.entities.Bot;
import core.entities.Player;
import core.net.client.GetTokenClass;

public class HeadlessApplicationListener extends Game {
	
	private GetTokenClass getToken;
	private int time = 0;

	@Override
	public void create() {
		init();
	}
	
	@Override
	public void render() {
		time++;
		try {
			if(!Core.state) return;
			if((Core.selectedServer >= 0 && Core.servers.size > 0 && Core.bots.size < Core.maxSize)) {
				if(time < 60) return;
				time = 0;
				Core.bots.add(new Bot(getToken.token(Core.servers.get(Core.selectedServer).ip)));
			}
		} catch (Exception e) {System.out.println(e);}
	}



	public void init() {
		Core.bots = new Array<Bot>();
		Core.selectedBots = new Array<Bot>();
		Core.players = new HashMap<Integer, Player>();
		Core.selectedPlayers = new Array<Player>();
		getToken = new GetTokenClass();
	}
}
