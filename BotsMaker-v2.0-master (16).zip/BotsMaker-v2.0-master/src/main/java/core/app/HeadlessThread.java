package core.app;

import com.badlogic.gdx.backends.headless.HeadlessApplication;

public class HeadlessThread extends Thread {

	@Override
	public void run() {
		new HeadlessApplication(new HeadlessApplicationListener());
	}
	
}
