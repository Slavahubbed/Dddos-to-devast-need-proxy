package core.app;

import com.badlogic.gdx.ApplicationListener;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.kotcrab.vis.ui.VisUI;

import core.Core;
import core.Textures;
import core.entities.Bot;
import core.ui.Menu;
import core.utils.Math2D;
import core.world.World;
import core.world.WorldRenderer;
import core.world.content.Units;

public class GraphicsApplicationListener implements ApplicationListener {
	
	private Menu menu;
	
	@Override
	public void create() {
		VisUI.load();
		Textures.load();
		Units.load();
		menu = new Menu();
		menu.init();
		Core.world = new World();
		Core.world.init();
		Gdx.input.setInputProcessor(new InputMultiplexer(menu.getStage(), WorldRenderer.stage));
	}

	@Override
	public void resize(int width, int height) {
		menu.resize(width, height);
		Core.world.resize(width, height);
	}

	@Override
	public void render() {
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		Gdx.gl.glClearColor(Color.valueOf("#3d5942").r, Color.valueOf("#3d5942").g, Color.valueOf("#3d5942").b, 1);
		Core.world.update(Gdx.graphics.getDeltaTime());
		menu.draw(Gdx.graphics.getDeltaTime());
		
		for(int i = 0; i < Core.bots.size; i++) {
			Core.bots.get(i).update();
		}
		
		update();
	}

	@Override
	public void pause() {
	}

	public void update() {
		if(Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
			for(Bot bot : Core.selectedBots) {
				bot.selected = false;
			}
			Core.selectedBots.clear();
		} else if(Gdx.input.isKeyJustPressed(Input.Keys.P)) {
			Core.canAtack = !Core.canAtack;
		} else if(Gdx.input.isKeyPressed(Input.Keys.PAGE_UP)) {
			Core.cameraZoom  -= 0.2f;
		} else if(Gdx.input.isKeyPressed(Input.Keys.PAGE_DOWN)) {
			Core.cameraZoom  += 0.2f;
		} else if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
			Core.canAtack = !Core.canAtack;
		}
		if(Core.cameraZoom < 1f) {
			Core.cameraZoom = 1f; 
		} else if(Core.cameraZoom > 30f) Core.cameraZoom = 30f;
	}
	
	@Override
	public void resume() {
	}

	@Override
	public void dispose() {
		System.exit(0);
	}
}
