package core.entities;

import java.util.HashMap;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import core.utils.groups.BlockEntityGroup;
import core.utils.groups.EntityGroup;
import core.utils.groups.ResideEntityGroup;
import core.utils.groups.UnitsEntityGroup;

public class ObjectListener {
	
	private HashMap<Integer, EntityGroup> groups;
	
	public void init() {
		groups = new HashMap<Integer, EntityGroup>();
		groups.put(0, new UnitsEntityGroup());
		groups.put(3, new BlockEntityGroup());
		groups.put(8, new ResideEntityGroup());
		groups.put(9, new ResideEntityGroup());
		groups.put(10, new ResideEntityGroup());
		groups.put(11, new ResideEntityGroup());
	}
	
	public void received(int pid, int id, int type, float x, float y, int extra, int state) {
		if(!groups.containsKey(type)) return;
		if(state == 0 && extra == 0) {
			groups.get(type).remove(pid, id, extra);
		} else groups.get(type).set(pid, id, type, x, y, (extra >> 5) & 31);
	}
	
	public void draw(SpriteBatch batch) {
		for(EntityGroup group : groups.values()) {
			group.draw(batch);
		}
	}
}
