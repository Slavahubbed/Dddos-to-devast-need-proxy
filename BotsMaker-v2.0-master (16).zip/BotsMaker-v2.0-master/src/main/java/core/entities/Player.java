package core.entities;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;

import core.Textures;
import core.Vars;
import core.world.WorldRenderer;
import core.world.actors.PlayerActor;

public class Player {
	
	public boolean selected = false;
	
	private int id;
	private Vector2 position;
	private PlayerActor playerActor;
	
	public Player(int id) {
		position = new Vector2();
		this.id = id;
		playerActor = new PlayerActor(this);
		playerActor.init();
		WorldRenderer.stage.addActor(playerActor);
	}
	
	public void updatePosition(float x, float y, float angle) {
		this.position.set(x, y);
	}
	
	public void drawOnSelected(Batch batch) {
		batch.draw(Textures.selectedTexture, position.x, position.y, Vars.tileSize, Vars.tileSize);
	}
	
	public int getId() {
		return id;
	}
	
	public Vector2 getPosition() {
		return position;
	}
}
