package core.entities;

import java.net.URI;

import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.math.Vector2;

import core.Core;
import core.Textures;
import core.Vars;
import core.net.client.BotWebSocketClient;
import core.utils.Math2D;
import core.world.WorldRenderer;
import core.world.actors.BotActor;

public class Bot {
	
	public int id = 0;
	public Vector2 position;
	public float angle;
	public int skin;
	
	public Player targetPlayer;
	public Vector2 targetPoint;
	
	private BotWebSocketClient client;
	
	private BotActor botActor;
	public boolean selected;
	
	public Bot(String token) throws Exception {
		position = new Vector2();
		targetPoint = new Vector2();
		
		client = new BotWebSocketClient(new URI("wss://" + Core.servers.get(Core.selectedServer).ip + "-default.lobby."+ Core.servers.get(Core.selectedServer).region +".rivet.run/?token=" + token), this);
		client.connect();
		
		targetPlayer = null;
	}
	
	public void onConnected() {
		client.send("[30, \"t4<K?Cn<4^UPu59aN3Mt\", \"171\", 7, 0, \"Test\", 0, null, 0]");
	}
	
	public void onClosed() {
		WorldRenderer.stage.getActors().removeValue(botActor, false);
	}
	
	public void update() {
		if(targetPlayer == null) {
			sendMove(Math2D.moveTo(position, targetPoint));
			angleTo(targetPoint);
		} else {
			sendMove(Math2D.moveTo(position, targetPlayer.getPosition()));
			angleTo(targetPlayer.getPosition());
		}
		if(Core.canAtack) atack();
	}
	
	public void onSelected(Batch batch) {
		batch.draw(Textures.selectedTexture, position.x, position.y, Vars.tileSize, Vars.tileSize);
		if(targetPlayer != null) targetPlayer.drawOnSelected(batch); else batch.draw(Textures.targetPointTexture, targetPoint.x, targetPoint.y, Vars.tileSize, Vars.tileSize);
	}
	
	public void onUpdate(float x, float y, float angle) {
		position.set(x, y);
		botActor.updatePosition(x, y);
		this.angle = angle;
	}
	
	public void onHandshake(int id) {
		this.id = id;
		botActor = new BotActor(this);
		WorldRenderer.stage.addActor(botActor);
	}
	
	public void atack() {
		if(!client.isOpen()) return;
		client.send("[4]");
		client.send("[5]");
	}
	
	public void angleTo(Vector2 target) {
		if(!client.isOpen()) return;
		float angle = Math2D.angleTo(position, target);
		sendAngle(Math2D.rad2deg(angle));
	}
	
	public void disconnect() {
		client.close();
	}
	
	public void sendMove(Vector2 move) {
		if(!client.isOpen()) return;
		int vel = 0;
		if(move.x > 0) vel |= 1;
		if(move.x < 0) vel |= 2;
		if(move.y > 0) vel |= 4;
		if(move.y < 0) vel |= 8;
		client.send("[2, " + vel + "]");
	}
	
	public void sendAngle(float d) {
		if(client.isOpen()) client.send("[6, " + d + "]");
	}
	
	public BotWebSocketClient getClient() {
		return client;
	}
}
