package core.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;

import core.world.tiles.Unit;

public class Entity {
	
	public Unit u;
	
	public Vector2 position;
	public int pid;
	public int uid;
	public int id;
	public int type;
	public int update;
	
	public Entity(int type) {
		this.type = type;
		position = new Vector2();
	}
	
	public Entity(String texture, int type) {
		this.type = type;
		position = new Vector2();
	}
	
	public void set(Entity entity) {
		this.position = entity.position;
		this.pid = entity.pid;
		this.uid = entity.uid;
		this.id = entity.id;
		this.type = entity.type;
		this.update = entity.update;
	}
	
	public void draw(SpriteBatch batch) {
	}
}
