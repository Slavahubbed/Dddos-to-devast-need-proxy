package core.net.server;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

public class GetServerListClass {
	public String serverList() {
		WebClient client = WebClient.create();
		WebClient.ResponseSpec response = client.get()
				.uri("https://matchmaker.api.rivet.gg/v1/lobbies/list")
				.header("Origin", "https://devast.io/")
				.accept(MediaType.APPLICATION_JSON)
				.retrieve();
		return response.bodyToMono(String.class).block();
	}
}
