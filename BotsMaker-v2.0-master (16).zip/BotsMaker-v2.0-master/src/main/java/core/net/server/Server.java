package core.net.server;

public class Server {
	public int id;
	public String ip;
	public String region;
	public String name;
	
	public Server(int id, String ip, String region, String name) {
		this.id = id;
		this.ip = ip;
		this.region = region;
		this.name = name;
	}
}
