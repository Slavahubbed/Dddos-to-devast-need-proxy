package core.net.client;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.jayway.jsonpath.JsonPath;

public class GetTokenClass {
	
	int id = 0;
	
	public String token(String server) {
		WebClient client = WebClient.create();
		WebClient.ResponseSpec responseSpec = client.post()
			    .uri("https://matchmaker.api.rivet.gg/v1/lobbies/join")
			    .header("Origin", "https://devast.io/")
			    .contentType(MediaType.APPLICATION_JSON)
			    .accept(MediaType.APPLICATION_JSON)
			    .bodyValue(("{ \"lobby_id\": \"" + server  + "\"}"))
			    .retrieve();
		return JsonPath.read(responseSpec.bodyToMono(String.class).block(), "lobby.player.token");
	}
}
