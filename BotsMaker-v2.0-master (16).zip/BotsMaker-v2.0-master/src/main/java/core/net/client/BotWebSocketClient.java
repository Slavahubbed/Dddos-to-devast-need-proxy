package core.net.client;

import java.net.URI;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import core.Core;
import core.entities.Bot;
import core.entities.ObjectListener;

public class BotWebSocketClient extends WebSocketClient {

	private Bot bot;
	public ObjectListener listener;
	
	public BotWebSocketClient(URI serverUri, Bot bot) {
		super(serverUri);
		this.bot = bot;
		addHeader("Origin", "http://devast.io/");
		setConnectionLostTimeout(10000);
		listener = new ObjectListener();
		listener.init();
	}

	@Override
	public void onOpen(ServerHandshake handshakedata) {
		System.out.println("Open");
		bot.onConnected();
	}

	@Override
	public void onMessage(String message) {
		System.out.println(message);
	}

	@Override
	public void onClose(int code, String reason, boolean remote) {
		System.out.println("Close: " + reason);
		Core.bots.removeValue(bot, false);
		bot.onClosed();
		Core.players.clear();
	}

	@Override
	public void onError(Exception ex) {
		Core.bots.removeValue(bot, false);
		ex.printStackTrace();
	}

	@Override
	public void onMessage(ByteBuffer bytes) {
		switch (bytes.get(0)) {
		case 0: onUnits(bytes); break;
		case 9: onHandshake(bytes); break;
		}
	}
	
	private void onUnits(ByteBuffer buffer) {
		short[] shortBuffer = new short[buffer.capacity() / 2];
		buffer.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shortBuffer);
		int lenght = (buffer.capacity() - 2) / 18;
		
		for(int i = 0, byteB = 2, shortB = 1; i < lenght; i++, byteB  += 18, shortB += 9) {
			int id = buffer.get(byteB);
			int pId = shortBuffer[shortB + 3];
			int type  = buffer.get(byteB + 3);
			int state = buffer.get(byteB + 2);
			float x = shortBuffer[shortB + 4];
			float y = shortBuffer[shortB + 5];
			float angle = buffer.get(byteB + 2);
			int extra = shortBuffer[shortB + 8];
			if(id == bot.id && type == 0) {
				bot.onUpdate(x, y, angle);
				continue;
			}
			listener.received(pId, id, type, x, y, extra, state);
		}
	}
	
	private void onHandshake(ByteBuffer buffer) {
		
		int botId = buffer.get(1);
		int len = (buffer.capacity() - 8) / 10;
		
		for(@SuppressWarnings("unused")
		int a = 8, b = 4, i = 0; i < len; i++, a += 10, b += 5) {
			int id = buffer.get(a);
			if(id == botId) {
				bot.skin = buffer.get(a + 4);
				System.out.println(bot.skin);
			}
		}
		bot.onHandshake(botId);
	}
}
