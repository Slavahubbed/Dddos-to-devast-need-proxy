package core;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class Textures {
	public static Texture selectedTexture;
	public static TextureRegion targetPointTexture, player, bot;
	
	public static void load() {
		bot = new TextureRegion(new Texture(Gdx.files.internal("sprites/bot.png")));
		selectedTexture = new Texture(Gdx.files.internal("sprites/selected.png"));
		targetPointTexture = new TextureRegion(new Texture(Gdx.files.internal("sprites/targetPoint.png")));
		player = new TextureRegion(new Texture(Gdx.files.internal("sprites/player.png")));
	}
}
