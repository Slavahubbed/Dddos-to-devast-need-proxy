package core;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;

import core.app.GraphicsApplicationListener;
import core.app.HeadlessThread;

public class DesktopLauncher {
	
	static Lwjgl3ApplicationConfiguration cfg = new Lwjgl3ApplicationConfiguration();
	
	public static void main(String[] args) {
		new HeadlessThread().start();
		cfg.setWindowedMode(1000, 800);
		cfg.setIdleFPS(60);
		new Lwjgl3Application(new GraphicsApplicationListener(), cfg);
	}
}
