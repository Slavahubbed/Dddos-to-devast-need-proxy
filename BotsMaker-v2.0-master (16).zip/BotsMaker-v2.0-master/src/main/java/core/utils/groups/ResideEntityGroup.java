package core.utils.groups;

import core.world.content.Blocks;
import core.world.tiles.Tile;

public class ResideEntityGroup extends EntityGroup {

	public ResideEntityGroup() {
		super(9);
	}
	
	@Override
	public void set(int pid, int id, int type, float x, float y, int skin) {
		Tile tile = new Tile(type);
		tile.block = Blocks.get(type, skin);
		tile.position.set(x, y);
		tile.pid = pid;
		
		if(entityGroup.containsKey(pid)) {
			entityGroup.get(pid).set(tile);
		} else {
			entityGroup.put(pid, tile);
		}
	}
}
