package core.utils.groups;

import java.util.HashMap;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import core.entities.Entity;

public class EntityGroup {
	
	private int type;
	protected HashMap<Integer, Entity> entityGroup;
	
	public EntityGroup(int type) {
		this.type = type;
		this.entityGroup = new HashMap<Integer, Entity>();
	}
	
	public void set(int pid, int id, int type, float x, float y, int skin) {
		Entity entity = new Entity(type);
		entity.pid = pid;
		entity.position.set(x, y);
		if(entityGroup.containsKey(pid)) {
			entityGroup.get(pid).set(entity);
		} else {
			entityGroup.put(pid, entity);
		}
	}
	
	public void draw(SpriteBatch batch) {
		try {
			for(Entity e : entityGroup.values()) {
				e.draw(batch);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public Entity get(int uid, int type) {
		if(this.type == type) return entityGroup.get(uid); else return null;
	}
	
	public void remove(int uid, int id, int extra) {
		entityGroup.remove(uid);
	}
	
	public int size() {
		return entityGroup.size();
	}
}
