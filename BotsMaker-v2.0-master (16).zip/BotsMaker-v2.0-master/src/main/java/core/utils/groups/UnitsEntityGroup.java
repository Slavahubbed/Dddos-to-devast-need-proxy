package core.utils.groups;

import core.Core;
import core.entities.Player;

public class UnitsEntityGroup extends EntityGroup {

	public UnitsEntityGroup() {
		super(0);
	}
	
	@Override
	public void set(int pid, int id, int type, float x, float y, int skin) {
		for(int i = 0; i < Core.bots.size; i++) if(Core.bots.get(i).id == id) return;
		if(id > 0) {
			System.out.println(id);
			if(Core.players.containsKey(id)) {
				Core.players.get(id).updatePosition(x, y, 0);
			} else {
				Core.players.put(id, new Player(id));
			}
		}
	}
}
