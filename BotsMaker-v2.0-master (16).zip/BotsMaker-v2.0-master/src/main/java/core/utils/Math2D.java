package core.utils;

import com.badlogic.gdx.math.Vector2;

public class Math2D {
	public static float angleTo(Vector2 begin, Vector2 end) {
		float vx = begin.x - end.x;
		float vy  = begin.y - end.y;
		
		return (float) Math.atan2(vy, vx);
	}
	
	public static float rad2deg(double angle) {
		float ang = (float) (angle * (180 /  Math.PI));
		if(ang < 0) angle += 360;
		ang = (ang  + 180) % 360;
		
		return ang;
	}
	
	public static float normolize(float angle) {
		if(angle < 0) angle += 360;
		angle = (angle - 90) % 360;
		
		return angle;
	}
	
	public static Vector2 moveTo(Vector2 position, Vector2 target) {
		Vector2 velocity = new Vector2();
		
		if(position.x > target.x) {
			velocity.x = 1;
		} else velocity.x = -1;
		if(position.y > target.y) {
			velocity.y = -1;
		} else velocity.y = 1;
		
		return velocity;
	}
	
	public static boolean dip(float a, float b, float c) {
		return Math.abs(a - b) < c;
	}
}
