package core;

public class Vars {
	/*WORLD*/
	public static final int tileSize = 100;
	public static float cameraSpeed = 50f;
}
